#include "pch.h"
#include "CDetectDef.h"
